$ErrorActionPreference = "Stop"

$installDir = "C:\iBrain-local-node"
$sourceAgent = Join-Path $PSScriptRoot "agent.py"
$targetAgent = Join-Path $installDir "agent.py"
$backupAgent = Join-Path $installDir ("agent.py.backup-" + (Get-Date -Format "yyyyMMdd-HHmmss"))

if (-not (Test-Path $sourceAgent)) {
    throw "找不到安裝包內的 agent.py"
}

New-Item -ItemType Directory -Force -Path "$installDir\legal-inbox\judicial" | Out-Null
New-Item -ItemType Directory -Force -Path "$installDir\judicial-output" | Out-Null

if (Test-Path $targetAgent) {
    Copy-Item $targetAgent $backupAgent -Force
    Write-Host "已備份原程式：$backupAgent"
}

Copy-Item $sourceAgent $targetAgent -Force
Write-Host "已安裝 iBrain 本機節點 0.6.3。"
Write-Host "司法 RAR 不會自動全量處理；請依 README 先跑單包 100 筆測試。"
