iBrain 本機節點 0.6.3－影音續傳與司法院裁判拆解測試版

一、安裝
1. 將壓縮檔解壓到任意資料夾。
2. 在「安裝司法拆解測試版.ps1」上按右鍵，以 PowerShell 執行。
3. 安裝器會先備份原本的 C:\iBrain-local-node\agent.py，再安裝新版。

二、代表性測試（從指定 RAR 全部清單平均抽取 100 筆，不上傳 Cloudflare）
在 PowerShell 執行：

$env:LOCAL_NODE_JUDICIAL_ENABLED="true"
$env:LOCAL_NODE_JUDICIAL_TEST_ARCHIVE="202602--(20260816Update).rar"
$env:LOCAL_NODE_JUDICIAL_MAX_DOCS="100"
python -u "C:\iBrain-local-node\agent.py"

看到「司法測試完成」後，可按 Ctrl+C 停止程式。

三、結果位置
C:\iBrain-local-node\judicial-output

每次測試會產生：
- completed.json：統計報告
- records.jsonl：裁判欄位及拆段結果
- errors.jsonl：無法解析的資料

四、安全設定
- .crdownload 不會被處理。
- 只有明確指定的 RAR 會執行。
- 測試版不會上傳司法資料到 Cloudflare。
- 以 JID 與全文 SHA-256 判斷相同版本。
- 原本教材、OCR、影音轉檔及心跳功能均保留。
- HLS 上傳遇到 Cloudflare 暫時錯誤會自動重試。
- 重新處理時沿用完整的本機 HLS，並略過雲端已有切片。
